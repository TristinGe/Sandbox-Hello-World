import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class HellowWorld extends PApplet {

//Global Variables
char x;
String y, z, d, e, f, ten, h, tens, one;
int two, twot, three, four, twenty, skipCount=2;
float thirty;
//
public void setup() 
{
  y = ",";
  z = ".";
  d = "I";
  //
  e = "count";
  f = "to";
  ten ="10";
  tens = "10000";
  twenty =PApplet.parseInt(tens);
  thirty =10000.0f; //must include decimal because it is a float
  h = "by";
  one = "1";
  two = 2; //only one formula to change
  twot = two; // Variable references the formula, Best Practice
  println(d, e, f, ten+y, h, PApplet.parseInt(two)+PApplet.parseInt(one)+z ); //Casting, making a STRING into a INTEGER
  println( "One plus one is", PApplet.parseInt(ten) );
}//End setup
//
public void draw() 
{
  thirty/=PApplet.parseInt(ten)/PApplet.parseInt(skipCount);
  println(d, e, f, PApplet.parseInt(twenty)+y, h, thirty+z );
  two-=skipCount;
  println(d, e, f, ten+y, h, two+z );
  twot*=twot+PApplet.parseInt(one);
  println(d, e, f, ten+y, h, twot+z );
  thirty+=skipCount;
  println(d, e, f, twenty+y, h, thirty+z );
}//End draw
//
public void keyPressed() {
}//End keyPressed
//
public void mousePressed() {
}//End mousePressed
//


/*
 char x = '!';
 String a = "You";
 String b = "said";
 String c = "Hello";
 char space = ' ';//"System Resources", use "char", choose your variables wisely for the hard dreive space (location by address)
 //println(a+space+b+space+c+x); //First Method of Concatenation, +
 //println(a, b, c+x); //Second Method of Concatenation, notice the spaces (human reading)
 //
 //Concatenate the Second Sentence
 //print(d+space+e+space+f+space+ten+y+space+h+space+one+z+"\n");//Character escape, \n (NEW LINE), \t (TAB)
 */
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "HellowWorld" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
